import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {
  updateuser: Users;
  constructor(private httpService: HttpClient) { }


  public login(loginUser: Users) {
    console.log("ins service loginUser");
    console.log(loginUser);
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.post("http://localhost:8586/login/user", loginUser,  { headers, responseType: 'text'});
  }
  public register(registerUser: Users) {
    console.log("ins service loginUser");
    console.log(registerUser);
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.post("http://localhost:8586/register/user", registerUser,  { headers, responseType: 'text'});
  }



    
  }
export class Users { 
  userid: string;
 password: string;
  phonenumber: number;
  name: string;
  role: string;
}