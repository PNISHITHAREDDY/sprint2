import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MyserviceService, Users } from '../myservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './app-login.component.html',
  styleUrls: ['./app-login.component.css']
})
export class LoginComponent implements OnInit {

  message: string;

  constructor(private myservice: MyserviceService,private router: Router) { }

  ngOnInit(): void {}

  OnSubmit (loginUser:Users):any{
    console.log(loginUser);
    console.log(loginUser.password);
    this.myservice.login(loginUser).subscribe(data => {
      this.message=data});
      if(loginUser.name == 'User'){
        this.router.navigateByUrl('/userLogin');
      }else{
        this.router.navigateByUrl('/adminLogin');
      }
         
      
 };
  
  

}
