import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  appointmentList=[{
  Centreid: "301",
  CentreName: "vijaya diagnostic center",
  Address: "Hi-Tech city"
  },
  {
    Centreid: "302",
    CentreName: "konark",
    Address: "Cyber city"
    },
    {
      Centreid: "303",
      CentreName: "Apollo",
      Address: "Alwal city"
      },
      {
        Centreid: "304",
        CentreName: "medquest",
        Address: "Tech city"
        }
]
  ///*  */console.log(appointmentList);
    constructor(private router: Router) { }
  
    ngOnInit(): void {
      console.log(this.appointmentList);

    }
    
  
  
    }
  
  